from resources.lib.externals.hachoir.hachoir_parser.network.tcpdump import TcpdumpFile

